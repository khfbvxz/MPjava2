package 상속;

public class 자식 extends 부모님{

	@Override
	public String toString() {
		return "자식 [a=" + a + ", b=" + b + ", c=" + c + "]";
	}
	
}
