package 상속;

public class 부모님 /*extends Object*/{
	public int a ; 
	protected int b;
	int c;
	private int d ;
	@Override
	public String toString() {
		return "부모님 [a=" + a + ", b=" + b + ", c=" + c + ", d=" + d + "]";
	}
	
}
